#include "Laborator3.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"

using namespace std;
bool direction = true;	// for square translation Ex3
float square_side = 100; // = squareSide from Laborator3::Init()
float center = 50;	// for square rotation Ex3 -- the square center is at lowerleftcorner + (square_side/2, square_side/2)
bool direction_bonus = true; // for square translation Bonus
float translateX_bonus;	// for square translation Bonus
float translateY_bonus; // for square translation Bonus


Laborator3::Laborator3()
{
}

Laborator3::~Laborator3()
{
}

void Laborator3::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);
	float squareSide = 100;

	// compute coordinates of square center
	float cx = corner.x + squareSide / 2;
	float cy = corner.y + squareSide / 2;
	
	// initialize tx and ty (the translation steps)
	translateX = 0;
	translateY = 0;
	translateX_bonus = 0;
	translateY_bonus = 0;

	// initialize sx and sy (the scale factors)
	scaleX = 1;
	scaleY = 1;
	
	// initialize angularStep
	angularStep = 0;
	

	Mesh* square1 = Object2D::CreateSquare("square1", corner, squareSide, glm::vec3(1, 0, 0), true);
	AddMeshToList(square1);
	
	Mesh* square2 = Object2D::CreateSquare("square2", corner, squareSide, glm::vec3(0, 1, 0));
	AddMeshToList(square2);

	Mesh* square3 = Object2D::CreateSquare("square3", corner, squareSide, glm::vec3(0, 0, 1));
	AddMeshToList(square3);

}

void Laborator3::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Laborator3::Update(float deltaTimeSeconds)
{
	// TODO: update steps for translation, rotation, scale, in order to create animations

	{
		// Translation
		// TODO: create animations by multiplying current transform matrix with matrices from Transform 2D
		// I used window->GetResolution().y - 250 - square_side and -250 to set borders for the movement
		// equal to the apparent borders of the window so it looks like the square hits them and bounces

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(150, 250);
		if (direction) {
			translateY += deltaTimeSeconds * 100;
			modelMatrix *= Transform2D::Translate(translateX, translateY);
			if (translateY > window->GetResolution().y - 250 - square_side) direction = false;
		}
		else{
			translateY -= deltaTimeSeconds * 100;
			modelMatrix *= Transform2D::Translate(translateX, translateY);
			if (translateY < -250) direction = true;
		}

		RenderMesh2D(meshes["square1"], shaders["VertexColor"], modelMatrix);
	}

	{
		// Rotation
		// TODO create animations by multiplying current transform matrix with matrices from Transform 2D
		// Applied the series of M = T * R * T^-1 by following the steps:
		// 1. Translate the center as 0 -> 2. Rotate -> 3. Translate back by making the coordinates of translation negative

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(400, 250);
		angularStep += deltaTimeSeconds / 2;
		modelMatrix *= Transform2D::Translate(center, center);
		modelMatrix *= Transform2D::Rotate(angularStep);
		modelMatrix *= Transform2D::Translate(-center, -center);
		RenderMesh2D(meshes["square2"], shaders["VertexColor"], modelMatrix);
	}

	{
		// Scalation
		// TODO create animations by multiplying current transform matrix with matrices from Transform 2D
		// Applied the series of M = T * S * T^-1 by following the steps:
		// 1. Translate the center as 0 -> 2. Scale -> 3. Translate back by making the coordinates of translation negative
		// The scale factor varies between 1 and 0 using the sinus function, this making the pulsating effect

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(650, 250);
		scaleX += deltaTimeSeconds / 2;	// The speed of scaling is here
		scaleY += deltaTimeSeconds / 2;
		modelMatrix *= Transform2D::Translate(center, center);
		modelMatrix *= Transform2D::Scale(2 * sin(scaleX), 2 * sin(scaleY));	// The amplitude of scaling is here
		modelMatrix *= Transform2D::Translate(-center, -center);
		RenderMesh2D(meshes["square3"], shaders["VertexColor"], modelMatrix);
	}

	{
		// Bonus
		// 1. Translation

		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(900, 250);
		if (direction_bonus) {
			translateY_bonus += deltaTimeSeconds * 100;
			modelMatrix *= Transform2D::Translate(translateX_bonus, translateY_bonus);
			if (translateY_bonus > window->GetResolution().y - 250 - square_side) direction_bonus = false;
		}
		else {
			translateY_bonus -= deltaTimeSeconds * 100;
			modelMatrix *= Transform2D::Translate(translateX_bonus, translateY_bonus);
			if (translateY_bonus < -250) direction_bonus = true;
		}

		RenderMesh2D(meshes["square1"], shaders["VertexColor"], modelMatrix);

		// 2. Rotation
		// Keeping the modelMatrix of the first square and Rotating it as normal +
		// Translating it back at a distance from the center of the first square

		angularStep += deltaTimeSeconds / 2;
		modelMatrix *= Transform2D::Translate(center, center);
		modelMatrix *= Transform2D::Rotate(angularStep);
		modelMatrix *= Transform2D::Translate(-3.5 * center, -3.5 * center);
		RenderMesh2D(meshes["square2"], shaders["VertexColor"], modelMatrix);
	}

}

void Laborator3::FrameEnd()
{

}

void Laborator3::OnInputUpdate(float deltaTime, int mods)
{
	
}

void Laborator3::OnKeyPress(int key, int mods)
{
	// add key press event
}

void Laborator3::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator3::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Laborator3::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator3::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator3::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator3::OnWindowResize(int width, int height)
{
}
